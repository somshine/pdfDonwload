package com.somshine.PDFDownload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfDownloadApplicationTests {

	@Test
	void contextLoads() {
	}

}
