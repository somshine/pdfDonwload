package com.somshine.PDFDownload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdfDownloadApplication {

	public static void main(String[] args) {
		SpringApplication.run(PdfDownloadApplication.class, args);
	}

}
